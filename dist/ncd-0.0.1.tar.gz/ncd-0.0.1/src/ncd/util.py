class NCDException(Exception):
    pass

class NCDStampException(NCDException):
    pass
